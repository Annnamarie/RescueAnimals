from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'SNHU2024'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30863
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client[DB]
        self.collection = self.database[COL]

    #C (create) in CRUD
    def create(self, data):
        if data is not None:
            self.collection.insert_one(data)
            #return true if the insert was successfull
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    #R (read) in CRUD
    def read(self, query):
        if query is not None:
            documents = self.collection.find(query)
            #return the list that was queried
            return list(documents)
        else:
            raise Exception("There was no query provided")
            
    #U (update) in CRUD
    def update(self, query, updated_data):
        if query is not None and updated_data is not None:
            result = self.collection.update_many(query, {'$set': updated_data})
            #returning the number of document/data that was updated
            return result.modified_count
        else:
            raise Exception("Both query and updated_data parameters are required")

    #D (delete) in CRUD
    def delete(self, query):
        if query is not None:
            result = self.collection.delete_many(query)
            # retunr the number of document/data that has been deleted
            return result.deleted_count
        else:
            raise Exception("There was no query provided")

